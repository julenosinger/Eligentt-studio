// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title ElligentCrossChainBatcher
 * @notice Allows sending multiple USDC cross-chain transfers from Arc in a single transaction.
 *         Each recipient still receives an independent CCTP message (standard CCTP limitation).
 *         This gives the user a single signature UX for many cross-chain payments.
 *
 * @dev Compatible with Circle CCTP v2 TokenMessenger on Arc Testnet.
 *      Only supports USDC for now (can be extended for EURC).
 */
interface ITokenMessengerV2 {
    function depositForBurn(
        uint256 amount,
        uint32 destinationDomain,
        bytes32 mintRecipient,
        address burnToken,
        bytes32 destinationCaller,
        uint256 maxFee,
        uint32 minFinalityThreshold
    ) external returns (uint64 nonce);

    function depositForBurnWithHook(
        uint256 amount,
        uint32 destinationDomain,
        bytes32 mintRecipient,
        address burnToken,
        bytes32 destinationCaller,
        uint256 maxFee,
        uint32 minFinalityThreshold,
        bytes calldata hookData
    ) external returns (uint64 nonce);
}

interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
}

contract ElligentCrossChainBatcher {
    address public immutable tokenMessenger;
    address public immutable usdc; // Native USDC on Arc

    event CrossChainBatchInitiated(
        address indexed sender,
        uint256 indexed batchId,
        uint256 totalAmount,
        uint256 recipientCount
    );

    event CrossChainTransferQueued(
        uint256 indexed batchId,
        uint256 indexed index,
        address recipient,
        uint256 amount,
        uint32 destinationDomain,
        bytes32 mintRecipient,
        uint64 nonce
    );

    uint256 private _batchCounter;

    constructor(address _tokenMessenger, address _usdc) {
        require(_tokenMessenger != address(0), "Invalid TokenMessenger");
        require(_usdc != address(0), "Invalid USDC");
        tokenMessenger = _tokenMessenger;
        usdc = _usdc;
    }

    /**
     * @notice Batch cross-chain USDC transfers from Arc using multiple depositForBurn calls.
     * @param amounts Array of amounts (6 decimals)
     * @param destinationDomains CCTP domains (e.g. 0 = Ethereum, 6 = Base, 3 = Arbitrum)
     * @param mintRecipients Array of recipient addresses converted to bytes32
     * @param maxFee Max relayer fee (usually 0 for Standard transfers from Arc)
     * @param minFinalityThreshold 2000 for Standard (recommended for most destinations from Arc)
     */
    function batchDepositForBurn(
        uint256[] calldata amounts,
        uint32[] calldata destinationDomains,
        bytes32[] calldata mintRecipients,
        uint256 maxFee,
        uint32 minFinalityThreshold
    ) external returns (uint64[] memory nonces) {
        uint256 len = amounts.length;
        require(len > 0, "No recipients");
        require(
            len == destinationDomains.length &&
            len == mintRecipients.length,
            "Array length mismatch"
        );

        // Calculate total and pull USDC once
        uint256 totalAmount = 0;
        for (uint256 i = 0; i < len; i++) {
            totalAmount += amounts[i];
        }

        // Transfer USDC from sender to this contract
        require(IERC20(usdc).transferFrom(msg.sender, address(this), totalAmount), "USDC transferFrom failed");

        // Approve TokenMessenger for the full amount
        require(IERC20(usdc).approve(tokenMessenger, totalAmount), "USDC approve failed");

        nonces = new uint64[](len);
        uint256 batchId = ++_batchCounter;

        uint256 totalSent = 0;

        for (uint256 i = 0; i < len; i++) {
            uint256 amt = amounts[i];
            require(amt > 0, "Amount must be > 0");

            uint64 nonce = ITokenMessengerV2(tokenMessenger).depositForBurn(
                amt,
                destinationDomains[i],
                mintRecipients[i],
                usdc,
                bytes32(0),           // destinationCaller = 0 (anyone can mint)
                maxFee,
                minFinalityThreshold
            );

            nonces[i] = nonce;
            totalSent += amt;

            emit CrossChainTransferQueued(
                batchId,
                i,
                address(uint160(uint256(mintRecipients[i]))), // for readability
                amt,
                destinationDomains[i],
                mintRecipients[i],
                nonce
            );
        }

        emit CrossChainBatchInitiated(msg.sender, batchId, totalSent, len);

        // Reset approval (good practice)
        require(IERC20(usdc).approve(tokenMessenger, 0), "Reset approve failed");
    }

    /**
     * @notice Batch version using depositForBurnWithHook.
     * Useful when many recipients are on the SAME destination chain:
     * you can point the mintRecipient to a "Distributor" hook contract on the destination
     * that will split the funds according to the hookData you provide.
     *
     * @param hookDatas Array of arbitrary bytes passed to the hook on destination.
     */
    function batchDepositForBurnWithHook(
        uint256[] calldata amounts,
        uint32[] calldata destinationDomains,
        bytes32[] calldata mintRecipients,
        bytes[] calldata hookDatas,
        uint256 maxFee,
        uint32 minFinalityThreshold
    ) external returns (uint64[] memory nonces) {
        uint256 len = amounts.length;
        require(len > 0, "No recipients");
        require(
            len == destinationDomains.length &&
            len == mintRecipients.length &&
            len == hookDatas.length,
            "Array length mismatch"
        );

        uint256 totalAmount = 0;
        for (uint256 i = 0; i < len; i++) {
            totalAmount += amounts[i];
        }

        require(IERC20(usdc).transferFrom(msg.sender, address(this), totalAmount), "USDC transferFrom failed");
        require(IERC20(usdc).approve(tokenMessenger, totalAmount), "USDC approve failed");

        nonces = new uint64[](len);
        uint256 batchId = ++_batchCounter;
        uint256 totalSent = 0;

        for (uint256 i = 0; i < len; i++) {
            uint256 amt = amounts[i];
            require(amt > 0, "Amount must be > 0");

            uint64 nonce = ITokenMessengerV2(tokenMessenger).depositForBurnWithHook(
                amt,
                destinationDomains[i],
                mintRecipients[i],
                usdc,
                bytes32(0),
                maxFee,
                minFinalityThreshold,
                hookDatas[i]
            );

            nonces[i] = nonce;
            totalSent += amt;

            emit CrossChainTransferQueued(
                batchId,
                i,
                address(uint160(uint256(mintRecipients[i]))),
                amt,
                destinationDomains[i],
                mintRecipients[i],
                nonce
            );
        }

        emit CrossChainBatchInitiated(msg.sender, batchId, totalSent, len);

        require(IERC20(usdc).approve(tokenMessenger, 0), "Reset approve failed");
    }

    /**
     * @notice Helper to convert address to bytes32 (same as Circle's standard)
     */
    function addressToBytes32(address addr) external pure returns (bytes32) {
        return bytes32(uint256(uint160(addr)));
    }

    function getCurrentBatchId() external view returns (uint256) {
        return _batchCounter;
    }
}
