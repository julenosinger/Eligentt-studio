# Deploying ElligentBatch.sol on Arc Testnet

## Contract Purpose
`ElligentBatch` allows sending USDC (and EURC) to hundreds of recipients in a **single transaction** on Arc Testnet. It is used by the Elligente dApp for the "Same-Chain Batch" (Arc → Arc) feature.

## Constructor Arguments (Arc Testnet)

```solidity
constructor(
    address _usdc,           // 0x3600000000000000000000000000000000000000
    address _eurc,           // 0x89B50855Aa3bE2F677cD6303Cec089B5F319D72a
    uint256 _initialFeeBps   // Recommended: 0 (or 10 = 0.1%, max 500 = 5%)
)
```

## Deployment Steps (Remix)

1. Open [Remix](https://remix.ethereum.org)
2. Create new file → paste `ElligentBatch.sol`
3. Compiler: 0.8.20 or higher
4. Deploy with the constructor arguments above
5. After deployment, copy the contract address
6. Paste it in the dApp under:
   - **Batch Payments → ElligentBatch Contract**

## Recommended Settings

- **Platform Fee**: Start with `0` (no fee) for testing
- Max recipients per batch: **500** (enforced in contract)

## Notes

- This contract is **only for same-chain** transfers (Arc → Arc).
- For cross-chain (Arc → other networks), use `ElligentCrossChainBatcher.sol` instead.
- The contract pulls tokens via `transferFrom` + takes an optional platform fee.

## Example Constructor Call (Remix)

```json
[
  "0x3600000000000000000000000000000000000000",   // USDC
  "0x89B50855Aa3bE2F677cD6303Cec089B5F319D72a",   // EURC
  0                                               // 0 fee
]
```

After deploying, update the address in the Elligente dApp.