// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title ElligentBatch
 * @notice Gas-efficient batch USDC/EURC transfers on Arc Testnet.
 *         Supports up to 500 recipients in a single transaction.
 *
 * @dev This contract is used by the Elligente dApp for same-chain (Arc → Arc) batch payments.
 */
interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function transfer(address to, uint256 amount) external returns (bool);
}

contract ElligentBatch {
    address public immutable usdc;
    address public immutable eurc;

    address public owner;
    uint256 public platformFeeBps; // in basis points (e.g. 100 = 1%)
    uint256 public batchCounter;

    event BatchTransfer(
        uint256 indexed batchId,
        address indexed sender,
        address token,
        uint256 totalAmount,
        uint256 recipientCount,
        uint256 feeAmount
    );

    event Transfer(
        uint256 indexed batchId,
        address indexed recipient,
        uint256 amount,
        string note
    );

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor(address _usdc, address _eurc, uint256 _initialFeeBps) {
        require(_usdc != address(0) && _eurc != address(0), "Invalid token");
        usdc = _usdc;
        eurc = _eurc;
        owner = msg.sender;
        platformFeeBps = _initialFeeBps;
    }

    /**
     * @notice Batch transfer tokens to multiple recipients.
     * @param recipients Array of recipient addresses
     * @param amounts Array of amounts (in token decimals)
     * @param notes Array of notes (on-chain memo for each transfer)
     */
    function batchTransfer(
        address[] calldata recipients,
        uint256[] calldata amounts,
        string[] calldata notes
    ) external {
        uint256 len = recipients.length;
        require(len > 0, "No recipients");
        require(len == amounts.length && len == notes.length, "Length mismatch");
        require(len <= 500, "Too many recipients");

        // Determine token (we support only USDC and EURC for now)
        // The dApp sends either all USDC or all EURC in one batch call
        address token = usdc; // default
        // We detect based on first transfer - but better to have separate functions
        // For simplicity in this version, we assume the caller knows what they're sending.

        // For now, this contract is mainly used with USDC.
        // If you need EURC batching, deploy another instance or extend this.

        uint256 totalAmount = 0;
        for (uint256 i = 0; i < len; i++) {
            totalAmount += amounts[i];
        }

        uint256 fee = (totalAmount * platformFeeBps) / 10000;
        uint256 amountToPull = totalAmount + fee;

        // Pull tokens from sender
        require(
            IERC20(usdc).transferFrom(msg.sender, address(this), amountToPull),
            "TransferFrom failed"
        );

        // Send to recipients
        for (uint256 i = 0; i < len; i++) {
            require(
                IERC20(usdc).transfer(recipients[i], amounts[i]),
                "Transfer failed"
            );
            emit Transfer(batchCounter, recipients[i], amounts[i], notes[i]);
        }

        // Send fee to owner (if any)
        if (fee > 0) {
            require(IERC20(usdc).transfer(owner, fee), "Fee transfer failed");
        }

        emit BatchTransfer(batchCounter, msg.sender, usdc, totalAmount, len, fee);

        batchCounter++;
    }

    /**
     * @notice Returns how much the sender needs to approve for a given total.
     *         Includes platform fee.
     */
    function getRequiredAllowance(uint256 totalAmount) external view returns (uint256) {
        uint256 fee = (totalAmount * platformFeeBps) / 10000;
        return totalAmount + fee;
    }

    function getVersion() external pure returns (string memory) {
        return "ElligentBatch v1.1";
    }

    // ========== Admin ==========

    function setPlatformFee(uint256 newFeeBps) external onlyOwner {
        require(newFeeBps <= 500, "Fee too high (max 5%)");
        platformFeeBps = newFeeBps;
    }

    function setOwner(address newOwner) external onlyOwner {
        require(newOwner != address(0), "Invalid owner");
        owner = newOwner;
    }

    // Emergency withdrawal (only owner)
    function withdrawToken(address token, uint256 amount) external onlyOwner {
        require(IERC20(token).transfer(owner, amount), "Withdraw failed");
    }
}