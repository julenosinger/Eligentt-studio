# Deploying ElligentCrossChainBatcher on Arc Testnet

## Contract
- File: `ElligentCrossChainBatcher.sol`
- Purpose: Batch multiple `depositForBurn` calls into a single user transaction (Arc → other CCTP chains)

## Deployment (Remix - easiest)

1. Go to https://remix.ethereum.org
2. Create new file `ElligentCrossChainBatcher.sol` and paste the full contract code.
3. Compiler: 0.8.20+
4. Deploy with these constructor arguments on **Arc Testnet**:

   - `_tokenMessenger`: `0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA` (TokenMessengerV2 on Arc)
   - `_usdc`: `0x3600000000000000000000000000000000000000` (Native USDC on Arc)

5. After deployment, copy the contract address and paste it in the dApp under:
   **Batch Payments → "Cross-Chain Batcher (Arc → Others)"**

## Important Notes

- This contract only initiates the burns. Each recipient still generates a separate CCTP message.
- After the batch transaction, you must complete the mint on each destination chain (using the nonces + Circle attestation).
- For production, consider adding a small platform fee or access control if desired.
- Start with small test amounts.

## Recommended Parameters (from Arc)

- `maxFee`: 0 (Standard transfers from Arc are free)
- `minFinalityThreshold`: 2000 (Standard) — Fast Transfer is not well supported from Arc yet.

## Next Steps (Future Improvements)

- Add support for EURC
- Add `depositForBurnWithHook` version for destination-side distribution
- Add a simple off-chain relayer/attestation helper in the dApp
