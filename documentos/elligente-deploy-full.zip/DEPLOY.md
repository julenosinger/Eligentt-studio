# Elligente — Cloudflare Pages Deploy Guide

## ✅ Ready-to-deploy package

This ZIP contains everything needed for production on Cloudflare Pages.

### Recommended: Deploy with Wrangler (easiest + supports Functions)

1. Unzip this package
2. Make sure you have Node.js 18+
3. Run:

```bash
npm install
npx wrangler pages deploy public --project-name elligente
```

   - First time it will ask you to create the project / log in.
   - After first deploy you can just repeat the command for updates.

### Alternative: Git integration (recommended for ongoing work)

- Push this code to your GitHub repo (the one you already have)
- In Cloudflare Dashboard → Pages → Connect to Git → select the repo
- Build settings:
  - Framework: None
  - Build command: (leave empty)
  - Build output directory: `public`
- Add environment variables (Secrets) if you use Circle keys:
  - `KIT_KEY`
  - `TEST_API_KEY`

### Direct Upload (Dashboard only — no CLI)

1. Unzip
2. Zip **only the `public/` folder** contents (or the whole folder)
3. In Cloudflare Pages → your project → "Upload assets"
4. For the Pages Function (`functions/index.js`):
   - After the first upload, go to Settings → Functions → paste the content of `functions/index.js` manually, or better use Wrangler the first time.

### Important for this dApp

- The swap and pool now correctly call the ElligentPool contract at:
  `0x18076d992005186AeB13AC5270CaD6E27DB95247`
- No separate ElligentSwap router is deployed — the code falls back to direct pool calls (this is the fix you requested).
- Update the contract addresses in `public/index.html` (the DEPLOYED block at the bottom) if you deploy new versions of the contracts.

### Environment Secrets (Cloudflare)

In your Pages project → Settings → Environment variables (Production):

- `KIT_KEY` → your Circle App Kit key
- `TEST_API_KEY` → Circle API key (for future features)

These are injected at runtime by `functions/index.js` and never appear in the HTML source.

## Test the Swap

1. Go to https://faucet.circle.com → select Arc Testnet → get USDC for the wallet you want to test.
2. Add liquidity in the "Liquidity" tab first (if the pool is empty).
3. Use the Swap tab → it will now correctly call the pool contract.

## Files included in this package

- public/ (the complete single-file dApp)
- functions/index.js (secure key injection)
- wrangler.jsonc
- package.json + package-lock.json
- README.md

## What's new in this package (May 29, 2026)
- Complete premium redesign of the **Payment Links** page:
  - Modern dashboard layout (Create form + Active Links side by side)
  - Strong glassmorphism + neon glow aesthetic
  - New futuristic header with animated icon glow
  - Improved inputs with icons and premium focus states
  - Gradient glowing primary button
  - Much better empty state with visual polish
  - Modern table + 4 feature cards at the bottom
  - Smooth hover animations and micro-interactions
- Schedule page date/time now uses clean US format (MM/DD/YYYY + AM/PM)
- Footer contacts visibility improved

All previous functionality (Multisend, Cross-Chain Batcher, Invoices, etc.) remains fully intact.
- UI reorganization: "Send Same-Chain (Arc → Arc)" and "Send Cross-Chain (Arc → Others)" buttons moved to the bottom action bar (next to Execute Queue / Execute in Parts) for better workflow.
- Schedule page: Date/time now displays in US format (MM/DD/YYYY + AM/PM).
- Footer contacts visibility improved.
- **Cross-Chain Multisend** support via `ElligentCrossChainBatcher`
- Same-chain batching uses the optional custom `ElligentBatch` contract (or direct transfers)
- Bug fixes for ENS resolution and addressToBytes32 errors
- Swap tab Recent Swaps history (session-only)
- Various UI/UX improvements in Batch Payments tab
- Contract addresses now persist in browser (no need to paste every time)

Happy deploying! 🚀

If you need a production build with your own keys injected or any other adjustment, just ask.
